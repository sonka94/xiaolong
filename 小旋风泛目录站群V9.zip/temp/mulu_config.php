<?php
return array (
  'ceshi2@' => 
  array (
    'id' => 14,
    'dirname' => '22222',
    'webname' => NULL,
    'mcode' => 'ceshi2@',
    'url' => 'http://ceshi2.cm/',
  ),
);
?>