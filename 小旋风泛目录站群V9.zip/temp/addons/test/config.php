<?php
return array (
  'name' => 'test',
  'danxuan' => '1',
  'input' => '单行文本',
  'textarea' => '',
  'addon_group' => '0',
);
?>