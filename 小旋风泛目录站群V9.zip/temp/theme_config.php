<?php
return array (
  'default/bjh' => '',
  'default/blog' => '',
  'default/mipb01' => '',
);
?>